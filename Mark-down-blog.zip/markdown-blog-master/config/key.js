module.exports = {
    mongoURI: "mongodb+srv://user1:Aritra02@type-o.pmpwf.mongodb.net/blogs?retryWrites=true&w=majority"
}