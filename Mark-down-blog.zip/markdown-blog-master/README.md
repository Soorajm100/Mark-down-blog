# Markdown-blog
This website uses passport.js to authenicate users and then lets them do crud opertations on their own articles and view other articles written by other users. Functionalities like Like,Dislike and Comment are also present for verified users. This website is live... link is: <a href="http://type-o-blogs.herokuapp.com"> Type-O Blogs </a>
